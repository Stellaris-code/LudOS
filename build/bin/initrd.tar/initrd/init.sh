setmode 1024x768
run greet.sh
setbckg wallpaper.png
