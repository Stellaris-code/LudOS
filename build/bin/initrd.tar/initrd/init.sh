setmode 1024x768
run greet.sh
set TERM_BCKG "/initrd/wallpaper_1024x768.png"
